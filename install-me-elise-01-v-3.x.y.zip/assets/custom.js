jQueryCS(document).ready(function($) {
  $(".dropdown-currency i").click(function(){
    $(".dropdown-inner").toggleClass("active");
    $(".dropdown-inner").slideToggle();
  });
});