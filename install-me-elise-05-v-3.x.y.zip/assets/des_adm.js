(function( $ ) {
   "use strict";
    // https://help.shopify.com/en/themes/development/sections/integration-with-theme-editor
    var sps = '#shopify-section-',
       tpk = 'type_packery',
       js_faq = 'js_faq_ad',
       tp_faq = 'type_faq',
       jpk = '.js_packery',
       tiso = 'type_isotope',
       jiso = '.js_isotope',
       tcr = 'type_carousel',
       tpin = 'type_pin_owl',
       jcr = 'js_carousel',
       jcr_ = '.js_carousel',
       tmr = 'type_masonry',
       thv = 'type_hero_video',
       jsv = '.js_video',
       jbody = $('body'),
       Tpr = jbody.hasClass('template-product'),
       tins = 'type_instagram',
       jins = '.js_cs_ist',
       jlb = 'js_lbcl',
       window_w = $(window).width(),
       jdocument = $(document),
       body = $('body'),
       alet_css_cs = $('#alet_css_cs'),
       sp_theme_id = Shopify.theme.id;

    $('.cp_cd_js').removeClass('dn');
    $('#sett_clcs').remove();


    if (t_name == 'collection'){
      cleverSopify.RefreshPriceTitle($('.filter_area_js'));
      cleverSopify.RefreshPriceTitle($('.js_sidebar'));
    }
    jdocument.on('shopify:section:load', function(e){
      var id = e.detail.sectionId,
          $parentSection = $(sps + id);
      $('.cp_cd_js').removeClass('dn');

      if ( $parentSection.hasClass(tcr) || $parentSection.hasClass(tpin) ) {
      } else if ( $parentSection.hasClass(tpk) ) {
         var el = $parentSection.find(jpk);
         cleverSopify.refresh_packery(el);
      } else if ( $parentSection.hasClass(tiso) ) {
           var el = $parentSection.find(jiso);
           cleverSopify.refresh_isotope(el);
      } else if ($parentSection.hasClass(js_faq)) {
        cleverSopify.spAccordion();
      } else if ($parentSection.hasClass(thv)) {
        var yt_src = '//www.youtube.com/iframe_api';
            $script(yt_src, 'loaded_v_js');
        var el = $parentSection.find(jsv);
        if (el.length == 0) return;
        cleverSopify.refresh_Youtube(el);
      } else if ($parentSection.hasClass(tins)) {
        var el = $parentSection.find(jins);
        cleverSopify.refresh_ins(el);
      }

      if ($parentSection.find('.cs_parallax_true').length > 0 ) {
         cleverSopify.parallax();
      }
      if ($parentSection.hasClass('tp_se_cdt')) {
        cleverSopify.InitCountdown();
      }
      if ($parentSection.hasClass('tp_se_cdt2')) {
        cleverSopify.InitSeCountdown();
      }

      cleverSopify.fullHeightRow();
      if (Tpr) {

         switch(id) {
           case 'pr_summary':
            cleverSopify.ATC_animation('#callBackVariant_ppr .single_add_to_cart_button');
            cleverSopify.NtproductPage();
            cleverSopify.InitCountdown_pr('#cs_countdow_ppr');
            cleverSopify.progressbar('#cs_stock_ppr');
            cleverSopify.delivery_order('#delivery_ppr');
            cleverSopify.real_time('#counter_ppr');
            cleverSopify.flashSold('#sold_ppr');
            if(typeof addthis !== 'undefined') {addthis.layers.refresh()}
            break;

           case 'product-recommendations':
             cleverSopify.PrRecommendations();
             break;

           case 'recently_viewed':
             cleverSopify.recently_viewed();
             break;

           case 'pr_description':
            cleverSopify.spAccordion();
            break;
         }

      }

      switch(id) {

        case 'header_7':
          cleverSopify.mobileNav();
          break;

        case 'collection_page':
          var el = $('#shopify-section-collection_page .cs_packery'),
              el1 = $('#shopify-section-collection_page .js_isotope');
          if ( el.length > 0) {
            cleverSopify.refresh_packery(el);
          } else if (el1.length > 0) {
            cleverSopify.refresh_isotope(el1);
          }
          break;

        case 'search_page':
          var el = $('#shopify-section-search_page .js_isotope');
          cleverSopify.refresh_isotope(el);
          break;

        case 'newsletter_pp':
          cleverSopify.NewsletterPopup();
          break;

        case 'age-verify':
          cleverSopify.ageVerify();
          break;
        case 'cookies-law':
          cleverSopify.cookiesLawPP();
          break;
        case 'promo_pr_pp':
          cleverSopify.PromoPrPopup();
          break;
        case 're_upsell':
          if ($('#mfp_re_upsell').length > 0) {
            $.magnificPopup.open({
              items: {
                src: '#mfp_re_upsell',
                type: 'inline'
              }
            });
            cleverSopify.refresh_flickity($('#mfp_re_upsell .cs_slider'));
            $('.cs_products_holder .pr_animated:not(.done)').addClass('done');
          }
        case 'sales_popup':
          cleverSopify.SalesPopup();
          break;
        case 'sticky_atc':
          cleverSopify.stickyAddToCart();
          cleverSopify.ATC_animation('#shopify-section-sticky_atc .single_add_to_cart_button');
          $('.sticky_atc_wrap').addClass('sticky_atc_shown');
          break;
      }
      // end switch

    });

    jdocument.on('shopify:section:unload', function(e){
      var id = e.detail.sectionId,
          $parentSection = $(sps + id);

      cleverSopify.fullHeightRow();
      if (Tpr && false) {
         cleverSopify.InitCountdown_pr('#cs_countdow_ppr');
         cleverSopify.progressbar('#cs_stock_ppr');
         cleverSopify.delivery_order('#delivery_ppr');
         if(typeof addthis !== 'undefined') {addthis.layers.refresh()}
      }
    });

    jdocument.on('shopify:section:select', function(e) {
      var id = e.detail.sectionId,
          $parentSection = $(sps + id);

      cleverSopify.fullHeightRow();

      if ( $parentSection.hasClass(tcr) || $parentSection.hasClass(tpin) ) {
          var el = $parentSection.find(jcr_);
          cleverSopify.refresh_flickity(el);
      } else if ( $parentSection.hasClass(tpk) ) {
           var el = $parentSection.find(jpk);
           cleverSopify.refresh_packery(el);
      } else if ( $parentSection.hasClass(tiso) ) {
           var el = $parentSection.find(jiso);
           cleverSopify.refresh_isotope(el);
      } else if ($parentSection.hasClass(thv)) {
        var el = $parentSection.find(jsv);
      } else if ($parentSection.hasClass('type_popup_video')) {
        cleverSopify.InitPopupVideo();
      } else if ($parentSection.hasClass('js_fetpr_se')) {
        cleverSopify.ProductSection(id);
        cleverSopify.refresh_flickity($('.p-thumb'+id));
      }

      switch(id) {
        case 'header_banner':
          cleverSopify.bannerCountdown();
          cleverSopify.hTransparent(true);
          break;
        case 'mb_nav':
        case 'mb_cat':
          $('.push_side.push-menu-btn:not(.act_current)').trigger('click');
          $('[data-id="#shopify-section-'+id+'_js"]').removeClass('active').trigger('click');
          break;

        case 'cs_filter':
        case 'cs_filter2':
          if ($(window).width() < 1025) {
            $('[data-opencs="#shopify-section-'+id+'"]').trigger('click');
          } else {
             $('.pop_default .js_filter,.cs_pop_sidebar [data-opencs="#shopify-section-'+id+'"]').trigger('click');
          }
          cleverSopify.RefreshPriceTitle($('.filter_area_js'));
          break;

        case 'sidebar-shop':
        case 'sidebar-shop2':
          if ($(window).width() < 1025) {
            $('[data-opencs="#shopify-section-sidebar-shop"]').trigger('click');
          } else {
             $('.cat_hidden_true .btn_sidebar').trigger('click');
          }
          cleverSopify.RefreshPriceTitle($('.js_sidebar'));
          break;
        case 'cs_custom_color':
          if ($('#admclnt').length > 0) {
            $.magnificPopup.open({
              items: {
                src: '#admclnt',
                type: 'inline'
              }
            });
          }
          break;
        case 'cart_widget':
          cleverSopify.cartLazyUp();
          $("[data-id='#cs_cart_canvas']").trigger('click');
          cleverSopify.cart_tls_ship();
          break;
        case 'collection_page':
          cleverSopify.RefreshPriceTitle($('.filter_area_js'));
          cleverSopify.RefreshPriceTitle($('.js_sidebar'));
          break;
        case 'footer_top':
          cleverSopify.footerCollapse();
          cleverSopify.stickyFooter();
          if ($('.footer_sticky_true').length == 0) {
            $('#cs_content').css({ marginBottom: 0 });
          }
          break;
        case 'newsletter_pp':
          $('.popup_new_wrap').trigger('open_newsletter');
          break;
        case 'age-verify':
          $('.popup_age_wrap').trigger('open_age_pp');
          break;
        case 'cookies-law':
          $('.popup_cookies_wrap').trigger('open_cookies_pp');
          break;
        case 'promo_pr_pp':
          $('.popup_prpr_wrap').trigger('open_promopr');
          setTimeout(function(){
           cleverSopify.refresh_flickity($('.popup_prpr_wrap .js_carousel'));
           cleverSopify.InitCountdown();
           body.trigger('refresh_currency');
          }, 650);
          break;
        case 're_upsell':
          if ($('#mfp_re_upsell').length > 0) {
            $.magnificPopup.open({
              items: {
                src: '#mfp_re_upsell',
                type: 'inline'
              }
            });
            cleverSopify.refresh_flickity($('#mfp_re_upsell .cs_slider'));
            $('.cs_products_holder .pr_animated:not(.done)').addClass('done');
          }
        case 'sales_popup':
          $('.popup_slpr_wrap').trigger('open_slpr_pp');
          break;
        case 'sticky_atc':
          $('.sticky_atc_wrap').addClass('sticky_atc_shown');
          setTimeout(function(){ $('.sticky_atc_wrap').addClass('sticky_atc_shown'); }, 500);
          break;

        default:
      }

    });

    jdocument.on('shopify:section:deselect', function(e) {
      var id = e.detail.sectionId,
      $parentSection = $(sps + id);

      if ($parentSection.hasClass('sp_header_mid')) {
         $('.sp_header_mid .menu-item').removeClass('menu_item_hover');
      }
      cleverSopify.fullHeightRow();

      switch(id) {

        case 'sidebar-shop':
        case 'cs_custom_color':
        case 'newsletter_pp':
        case 'age-verify':
        case 'promo_pr_pp':
        case 're_upsell':
          $.magnificPopup.close();
          break;

        case 'mb_nav':
        case 'mb_cat':
        case 'cart_widget':
          $('.mask-overlay').trigger('click');
          break;

        case 'cs_filter':
        case 'cs_filter2':
          $('.js_filter.opened').trigger('click');
          $.magnificPopup.close();
          break;

        case 'cookies-law':
          $('#shopify-section-cookies-law').removeClass('pp_onshow').addClass('pp_onhide');
          break;
        case 'sales_popup':
         $('.pp_slpr_close').trigger('click');
          break;

        default:
      }
    });

    jdocument.on('shopify:block:select', function(e){
        var id = e.detail.sectionId, blockId = e.detail.blockId,
          $parentSection = $(sps + id);

        if ($parentSection.hasClass('type_tab')) {
            $('.tab_se_element:not(.lazyload)').addClass('lazyload').one('lazyincluded', function(e) {
              body.trigger('refresh_currency');
              cleverSopify.InitCountdown();
              var el = $(e.target)[0], owl = $(el).find('.js_carousel');

              if (owl.length == 0 ) return;
              cleverSopify.refresh_flickity(owl);
            });
          cleverSopify.catTabs();
          $('a[data-bid="'+blockId+'"]').trigger('click');
        } else if ( $parentSection.hasClass(tcr) ) {
          flickityBlock.select($parentSection,blockId);
          cleverSopify.InitHTMLVideo();
        } else if ( $parentSection.hasClass(tpin) ) {
            var $blockID = $('#pin_'+blockId);
            if (!$blockID.hasClass('pin__wr_js')) {
              var parentID = $blockID.attr('data-i');
              $blockID = $('#pin_'+parentID);
            }
             $parentSection.find(jcr_).flickity('selectCell', $blockID.index() );
             $parentSection.find(jcr_).flickity('pausePlayer');
            setTimeout(function(){
              $('.pin__type_'+blockId+' .mfp_js:not(.current_clicked)').trigger('click');
              $('.hotspot_'+blockId+'.mfp_js:not(.current_clicked)').trigger('click');
          }, 350);
        } else if ($parentSection.hasClass(tmr)) {
          // mansonry
        } else if ($parentSection.hasClass(tpk) && $parentSection.hasClass(jlb)) {

          var el = $parentSection.find(jpk);
          cleverSopify.refresh_packery(el);
          $('.pin__type_'+blockId+'.pin__opened').trigger('click');
          setTimeout(function(){ $('.pin__type_'+blockId+':not(.pin__opened) .pin_tt_js').trigger('click');}, 350);

        } else if ($parentSection.hasClass(tpk)) {

           var el = $parentSection.find(jpk);
           cleverSopify.refresh_packery(el);

        } else if ($parentSection.hasClass(thv)) {

           var el = $parentSection.find(jsv);
          cleverSopify.refresh_Youtube(el);
          cleverSopify.InitHTMLVideo();

        } else if (id == "hcat_nav" ) {

          $('.lazy_h_cat').html($('#html_hcat_nav').html());
          $('.ha8_cat').addClass('menu_item_hover');

        } else if ($parentSection.hasClass('sp_header_mid')) {

          if ($('#bkjs_'+blockId).length > 0 ) {
            var li = $('.has-children#item_'+$('#bkjs_'+blockId).attr("data-id"));
          } else {
            var li = $('.has-children#item_'+blockId);
          }
           $('.sp_header_mid .menu-item').removeClass('menu_item_hover');
           li.addClass('menu_item_hover');
           if (li.hasClass('menu_has_offsets')) { cleverSopify.initMegaMenu(li); }


          $('.lazy_menu_mega').one('lazyincluded', function(e) {

            if (li.hasClass('menu_has_offsets')) { cleverSopify.initMegaMenu(li); }
            var el = $(e.target),
                option = JSON.parse(el.attr("data-jspackery"));
            option.originLeft = body.hasClass('rtl_false');
            el.packery(option);

            body.trigger('refresh_currency');
            cleverSopify.InitSeCountdown();
            if (el.find('.js_carousel.flickity-enabled').length > 0 ) return;
            cleverSopify.refresh_flickity(el.find('.js_carousel'));
          });
        } else if ($parentSection.hasClass(jlb)) {
          $('.pin__type_'+blockId+'.pin__opened').trigger('click');
          setTimeout(function(){ $('.pin__type_'+blockId+':not(.pin__opened) .pin_tt_js').trigger('click');}, 350);

        }

        if (id == 'footer_top') {
          $('.footer_collapse_true #block_'+blockId+':not(.footer_opened)>.widget-title').trigger('click');
        } else if (id == 'mb_nav' || id == 'mb_cat' || id == 'header_7') {
          $('#item_'+blockId+':not(.cs_opended)>a .nav_link_icon').trigger('click');
        } else if (id == 'cs_custom_color') {
          $('#item_'+blockId).addClass('selected');
          if ($('#admclnt').length > 0 && $('.mfp-content #admclnt').length == 0) {
            $.magnificPopup.open({
              items: {
                src: '#admclnt',
                type: 'inline'
              }
            });
          }
        } else if (id == 'pr_description') {

          if ( $('.des_style_2').length > 0 || ( $('.des_mb_2').length > 0 && $(window).width() < 1025 ) ) {
            $('#tab_'+blockId+' .tab-heading').trigger('click');
          } else {
            $('ul.des_style_1>li>a[href="#tab_'+blockId+'"]').trigger('click');
          }

        } else if ($parentSection.hasClass(tp_faq)) {
           $('#tab_'+blockId+' .tab-heading').trigger('click');
        }


         if (Tpr) {
            cleverSopify.InitCountdown_pr('#cs_countdow_ppr');
            cleverSopify.progressbar('#cs_stock_ppr');
         }

    });

    jdocument.on('shopify:block:deselect', function(e){
        var id = e.detail.sectionId, blockId = e.detail.blockId,
          $parentSection = $(sps + id);

        if ( $parentSection.hasClass(tcr) ) {
          flickityBlock.deselect($parentSection)
        } else if ( $parentSection.hasClass(tpin) ) {
           flickityBlock.deselect($parentSection);
           $.magnificPopup.close();
        } else if ( $parentSection.hasClass(tmr) ){
        } else if ( $parentSection.hasClass(tpk) ) {
           var el = $parentSection.find(jpk);
           cleverSopify.refresh_packery(el);
        } else if (id == "hcat_nav" ) {
          $('.ha8_cat').removeClass('menu_item_hover');
        } else if ($parentSection.hasClass('sp_header_mid')) {
         $('.sp_header_mid .menu-item').removeClass('menu_item_hover');
        } else if ($parentSection.hasClass(jlb)) {
          $('.pin__type_'+blockId+'.pin__opened').trigger('click');
        }

        if (id == 'footer_top') {
          $('.footer_collapse_true #block_'+blockId+'.footer_opened>.widget-title').trigger('click');
        } else if (id == 'mb_nav' || id == 'mb_cat' || id == 'header_7') {
          $('#item_'+blockId+'.cs_opended>a .nav_link_icon').trigger('click');
        } else if (id == 'cs_custom_color') {
          $('#item_'+blockId).removeClass('selected');
        } else if (id == 'pr_description') {
          if ( $('.des_style_2').length > 0 || ( $('.des_mb_2').length > 0 && $(window).width() < 1025 ) ) {
            $('.active#tab_'+blockId+' .tab-heading').trigger('click');
          }

        } else if ($parentSection.hasClass(tp_faq)) {
           $('.active#tab_'+blockId+' .tab-heading').trigger('click');
        }

         if (Tpr) {
            cleverSopify.InitCountdown_pr('#cs_countdow_ppr');
            cleverSopify.progressbar('#cs_stock_ppr');
            cleverSopify.delivery_order('#delivery_ppr');
            if(typeof addthis !== 'undefined') {addthis.layers.refresh()}
         }

    });

    var flickityBlock = {
      select: function($parentSection,blockId){

        if ($('#cs_'+blockId).length > 0) {
          var index = $('#cs_'+blockId).index();
        } else {
          var index = $('#b_'+blockId).closest('.slideshow__slide').index();
        }
        var $block_id = $('#cs_'+blockId)
         $parentSection.find(jcr_).flickity( 'select', index );
         $parentSection.find(jcr_).flickity('pausePlayer')
      },
      deselect: function($parentSection){
        $parentSection.find(jcr_).flickity('unpausePlayer')
      }
    };

    // Creates or updates an asset for a theme.
    // https://help.shopify.com/en/api/reference/online-store/asset#update-2019-07
    var csrf_token = 'no_token';
    $.ajax({
      type: "GET",
      url: "/admin/pages",
      success: function (data){
        csrf_token = data.split('name="csrf-token"')[1].split(" />")[0].split('"')[1];
      }
    });

    jdocument.on('click', '.put_asset_js', function(e) {
         var _this = $(this),
            key = _this.attr('data-key'),
            _sl = _this.attr('data-sl');

          _this.addClass('loading');
          $('#ld_cl_bar').trigger( "ld_bar_star" );

          $.ajax({
            url:  '/admin/api/2020-10/themes/'+sp_theme_id+'/assets.json',
            type: 'PUT',
            headers: {
                "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                "x-csrf-token": csrf_token
            },
            data: {asset: {"key": key,"value":$(_sl).html() }},
          }).done(function() {
            console.log("Update Complete");
            _this.removeClass('loading').addClass('cs_done');
            $('#ld_cl_bar').trigger( "ld_bar_end" );
            setTimeout(function(){ _this.removeClass('cs_done'); }, 1000);
          });
     });

    jdocument.on('click', '.dcp_cd_btn', function(e) {
        var _this = $(this),
        html = _this.siblings('.dcp_cd_ip')[0];
        html.select();
        html.setSelectionRange(0, 99999)
        document.execCommand("copy");
        _this.text('Copied Shortcode');
    });
    // open-import
    var $win_parent = $( window.parent.document);

    jdocument.on('click', '#enable_tag', function(e) {

      if ($('.cs-import').length > 0 ) {
          body.addClass('open-import');
      } else {
        var _this = $(this);
        _this.addClass('up_loading');
        fetch(_this.data('href'))
        .then(response => response.text())
        .then(data => {
          body.append(data).addClass('open-import');
          _this.removeClass('up_loading');
        })
        .catch((error) => {
          _this.removeClass('up_loading');
          console.error('Error:', error);
        });
      }

    });

    //find iframe

    // find button inside iframe
    var parent$ = $,
        btnSave = parent$('[data-role="save"]'),
        cs_style = $('#cs_style_update_css'),
        unck = true,
        unsave = false;

    // end click update
    $('.clever_tools_btns').addClass('on_show');

    // purchare code
      // check purchase code
      var purchase_codecs = $(ThemePuCS);
      if (ThemeIdLoCS == 'true' || ThemeIdCS == 'true') {
         purchase_codecs.remove();
      } else {
         $(ThemePuCS).removeClass('hide hidden');
         var ipt_codecs = $("#ipt_codecs"),
           res_codecs = $('#res_codecs'),
           shop_email = purchase_codecs.attr('data-email'),
           val_codecs = ipt_codecs.val();

         if ((purchase_codecs.is(":hidden") || purchase_codecs.length == 0)) {
            body.append('<section id="purchase_codecs" style="display:flex!important;"><h2 id="heading_codecs">Please activate to use theme</h2></section>');
           if (Shopify.theme.role != 'demo') {
               $.ajax({
                  type: "PUT",
                  url: '/admin/api/2020-10/themes/'+sp_theme_id+'.json',
                  headers: {
                      "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                      "x-csrf-token": csrf_token
                  },
                  dataType: 'json',
                  data: {
                   "theme": {
                     "id": sp_theme_id,"role": "demo"
                   }
                  },
                  success: function(data) {
                   top.window.location.reload();
                   //console.log(data);
                  }
               });
           }
         }
         $("#btn_codecs").on('click', function (e) {
            e.preventDefault();
            e.stopPropagation();
            var _this = $(this),
                curent_vlCodecs = ipt_codecs.val();

            if ( curent_vlCodecs == val_codecs ) {
              if (ipt_codecs.hasClass('csWarning')) {
                ipt_codecs.removeClass('shakecscode').addClass('csWarning2');
                setTimeout(function(){ ipt_codecs.addClass('shakecscode'); }, 100);
              } else {
                ipt_codecs.addClass('csWarning shakecscode');
              }
            } else {
             val_codecs = curent_vlCodecs;
             ipt_codecs.attr('class','');
             _this.addClass('loading');
              var domain = window.location.hostname;
              var mix = ['4','t','h','e','p','l','i','c','o','/','.',':','n','s','v','f','y','m','r'];
              var mix_domain = mix[2]+mix[1]+mix[1]+mix[4]+mix[13]+mix[11]+mix[9]+mix[9]+mix[7]+mix[5]+mix[3]+mix[14]+mix[3]+mix[18]+mix[13]+mix[8]+mix[4]+mix[6]+mix[15]+mix[16]+mix[10]+mix[7]+mix[8]+mix[17]+mix[9];
              var data = {
                  "shopify_domain":domain,
                  "email":shop_email,
                  "theme":ThemeNameCS,
                  "purchase_code": curent_vlCodecs
              };

              fetch(mix_domain, {
                  "headers": {
                    "accept": "*/*",
                    "cache-control": "no-cache",
                    "x-requested-with": "XMLHttpRequest"
                  },
                  "body": btoa (encodeURIComponent(JSON.stringify(data))) ,
                  "method": "POST",
                  "mode": "cors"
              }).then((response)=>{
                if(response.ok){
                return response.json()
                } throw ""
              }).then((response)=>{
                if ( response.status == 1) {
                  res_codecs.html("ACTIVATION SUCCESSFULLY. Thanks for buying my theme!").slideDown(250);
                  localStorage.setItem(ThemeNameCS2, "true");
                  _this.removeClass('loading');
                   setTimeout(function(){

                    purchase_codecs.remove();

                   }, 1350);

                  $.ajax({
                    type: "GET",
                    url: "/admin/pages",
                    success: function (data){
                      csrf_token = data.split('name="csrf-token"')[1].split("/>")[0].split('"')[1];
                      $.ajax({
                        type: "POST",
                        url: "/admin/api/2020-10/metafields.json",
                        headers: {
                          "content-type": "application/x-www-form-urlencoded; charset=UTF-8",
                          "x-csrf-token": csrf_token
                        },
                        data : {
                          metafield: {
                            namespace: 'cspcc',
                            description: 'clever_purchase_code',
                            key : ThemeNameCS,
                            value: 'true',
                            value_type: 'string'
                          }
                        }
                      }).done(function() {
                         purchase_codecs.remove();
                         _this.removeClass('loading');
                      }).fail(function() {
                         _this.removeClass('loading');
                      });
                    }
                  });
                } else {
                   _this.removeClass('loading');
                  if (response.message.length == 58) {
                   res_codecs.html("That license key doesn't appear to be valid. Please check your purchase code again!<br> Please email <a class='cg' href='mailto:hello@cleversoft.co' target='_blank'><span>hello@cleversoft.co</span></a> if you have any question.").slideDown(250);
                  } else {
                   try {
                      var mess = response.message.split('active domain `')[1].split('`. ')[0];
                    }
                    catch(err) {
                      var mess = response.message;
                    }
                   res_codecs.html("That license key has been invalidated, due to being active domain "+mess+".<br> Please email <a class='cg' href='mailto:hello@cleversoft.co' target='_blank'><span>hello@cleversoft.co</span></a> if you have any question.").slideDown(250);
                  }
                }

              }).catch((e)=>{
                 _this.removeClass('loading');
                console.error(e)
              });


            }
         });
      }
      // end check purchase code
})( jQueryCS );

jQueryCS(window).resize(function(){
  cleverSopify.footerCollapse();
});