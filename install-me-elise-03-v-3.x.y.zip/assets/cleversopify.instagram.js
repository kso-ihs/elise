// via Legacy API: 7016307166.1677ed0.c4674f47a3d649e48b97be06c5a437e6
// https://developers.facebook.com/docs/instagram-basic-display-api/reference/media
(function( $ ) {
   "use strict";

    cleverSopify.refresh_ins = function (_this) {
      var datalm = null, data = null, id = '', 
          getBy = _this.data('getby'),
          dtid = _this.data('id'),
          limit = _this.data('limit'),
          deafult_txt = 'spcs_cs',
          acc = _this.data('acc') || deafult_txt;
         
      if (acc == deafult_txt) return;
      if (sp_cs_storage) { datalm = sessionStorage.getItem('cs_ins'+acc+dtid);data = sessionStorage.getItem('cs_ins'+acc) }

      if ( datalm != null && data != '' ) {

           _this.html(datalm).parent().addClass('ins_loaded');
           if ( !_this.hasClass('js_carousel')) return;
           cleverSopify.refresh_flickity(_this);

           return false;
      }

       if ( data != null && data != '' ) {
            data = JSON.parse(data);
            ins_js(_this,data,false,acc,limit,dtid);

      } else {
           if (acc == 'ins_19041994') {
            var ajaxUrl = cs_settings.ins_host+'/instagram/media?shop='+Shopify.shop+'&resource=default';
           } else {
            var ajaxUrl = 'https://graph.instagram.com/me/media?fields=comments_count,like_count,id,media_type,media_url,permalink,thumbnail_url,caption,children&access_token='+acc;
           }
           $.ajax({
             url: ajaxUrl,
             type: 'GET',
             dataType: "json",
             success: function (res) {
               var data = (acc == 'ins_19041994') ? res : res.data;
               ins_js(_this,data,true,acc,limit,dtid);
             },
             error: function (e) {
               console.error("Instagram Feed:error acc1");
              fetch(ajaxUrl).then((response) => {
                  response.json().then((media) => {
                    var media_txt = media.message || 'no_txt';
                    if (media_txt != 'no_txt') {
                      _this.html('<div class="tc cr tu fwm col-12">'+media_txt+'</div>').parent().addClass('ins_loaded');
                      return false;
                    }
                    // media is a json containing the data about the 25 latest media.
                    var data = (acc == 'ins_19041994') ? media : media.data;
                    ins_js(_this,data,true,acc,limit,dtid);
                  });
              });
             }
           });
      }
    };

    function ins_js(_this,data,bl,acc,limit,dtid) {
      var html = '',
          bl = bl || true,
          cl = _this.data('cl'),
          cltb = _this.data('cltb'),
          clmb = _this.data('clmb'), 
          target = _this.data('target');

          $.each(data, function (index, el) {
             if (index >= limit) return 0;
             var img_url = el.thumbnail_url || el.media_url;
             html += '<div class="cl_cs_'+index+' col_ins col-'+clmb+' col-md-'+cltb+' col-lg-'+cl+' item pr ins_media_type_'+el.media_type+'"><a data-no-instant rel="nofollow" class="db pr oh" href="'+el.permalink+'" target="' + target + '"><div class="lazyload cs_bg_lz pr_lazy_img" data-bg="' + img_url + '" data-sizes="auto"></div><div class="info pa tc flex ts__03 fl_center al_center op__0 t__0 l__0 r__0 b__0 h__100 pe_none"><span class="pr cw"><i class="las la-video"></i><i class="las la-image"></i></span></div></a></div>';
          });

        _this.html(html).parent().addClass('ins_loaded');
        
        if ( _this.hasClass('js_carousel')) {
          cleverSopify.refresh_flickity(_this);
        }

        if (sp_cs_storage && bl) { 
           sessionStorage.setItem('cs_ins'+acc+dtid, html);
           sessionStorage.setItem('cs_ins'+acc, JSON.stringify(data));
        }
   };

    cleverSopify.instagram = function () {
      if ( $(".js_cs_ist").length == 0 ) return;
      
      $(".js_cs_ist").each(function (index) {
         cleverSopify.refresh_ins($(this));
      });
    };

})( jQueryCS );

jQueryCS(document).ready(function($) {

  cleverSopify.instagram();

  $('.js_sidebar').on('lazyincluded', function(e) {
    // console.log('js_sidebar load')
    cleverSopify.instagram();
    $('body').trigger('refresh_currency'); 
  });
});