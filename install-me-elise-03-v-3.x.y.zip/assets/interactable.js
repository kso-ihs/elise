/*! hoverIntent v1.10.0 */
!function(factory){"use strict";"function"==typeof define&&define.amd?define(["jQueryCS"],factory):"object"==typeof module&&module.exports?module.exports=factory(require("jQueryCS")):jQueryCS&&!jQueryCS.fn.hoverIntent&&factory(jQueryCS)}(function($){"use strict";var cX,cY,_cfg={interval:100,sensitivity:6,timeout:0},INSTANCE_COUNT=0,track=function(ev){cX=ev.pageX,cY=ev.pageY},compare=function(ev,$el,s,cfg){if(Math.sqrt((s.pX-cX)*(s.pX-cX)+(s.pY-cY)*(s.pY-cY))<cfg.sensitivity)return $el.off(s.event,track),delete s.timeoutId,s.isActive=!0,ev.pageX=cX,ev.pageY=cY,delete s.pX,delete s.pY,cfg.over.apply($el[0],[ev]);s.pX=cX,s.pY=cY,s.timeoutId=setTimeout(function(){compare(ev,$el,s,cfg)},cfg.interval)};$.fn.hoverIntent=function(handlerIn,handlerOut,selector){var instanceId=INSTANCE_COUNT++,cfg=$.extend({},_cfg);$.isPlainObject(handlerIn)?(cfg=$.extend(cfg,handlerIn),$.isFunction(cfg.out)||(cfg.out=cfg.over)):cfg=$.isFunction(handlerOut)?$.extend(cfg,{over:handlerIn,out:handlerOut,selector:selector}):$.extend(cfg,{over:handlerIn,out:handlerIn,selector:handlerOut});var handleHover=function(e){var ev=$.extend({},e),$el=$(this),hoverIntentData=$el.data("hoverIntent");hoverIntentData||$el.data("hoverIntent",hoverIntentData={});var state=hoverIntentData[instanceId];state||(hoverIntentData[instanceId]=state={id:instanceId}),state.timeoutId&&(state.timeoutId=clearTimeout(state.timeoutId));var mousemove=state.event="mousemove.hoverIntent.hoverIntent"+instanceId;if("mouseenter"===e.type){if(state.isActive)return;state.pX=ev.pageX,state.pY=ev.pageY,$el.off(mousemove,track).on(mousemove,track),state.timeoutId=setTimeout(function(){compare(ev,$el,state,cfg)},cfg.interval)}else{if(!state.isActive)return;$el.off(mousemove,track),state.timeoutId=setTimeout(function(){!function(ev,$el,s,out){delete $el.data("hoverIntent")[s.id],out.apply($el[0],[ev])}(ev,$el,state,cfg.out)},cfg.timeout)}};return this.on({"mouseenter.hoverIntent":handleHover,"mouseleave.hoverIntent":handleHover},cfg.selector)}});

 (function( $ ) {
   "use strict";
    var body = $('body'),
       _rtl = body.hasClass('rtl_true'),
       $ld = $('#ld_cl_bar'),
       yesHover = Modernizr.hovermq,
       touchevents = Modernizr.touchevents,
       window_w = $(window).width(),
       wis_csjs = $('#wis_csjs'),
       wis_view = wis_csjs.data('get'),
       use_vimg = cs_settings.use_vimg,
       cleverTheme = {
          popupAnimation: 'mfp-move-horizontal',
          ajaxSelector: '#cat_shopify a:not(.nav-expand-link),.cat-shop #cat_shopify a.nav-expand-link, #cs_sortby .wrap_sortby a, .cs_ajaxFilter a, .paginate_ajax a, .nav_filters a, .widget_product_tag_cloud a,a.clear_filter',
          scrollSelector: '.shopify-error a[href^="#"]',
          cs_btn_load_more : '.load-on-scroll:not(.btn--loader-active)',
          money_format : '${{amount}}'
    };

    cleverSopify.swatchesOnBGGrid = function() {
       var hide_ic_lz = 'hide_ic_lz';
       var swatches_js = function ( $this ) {
            var imagebg = $this.data('bgset'),
               paddingImg = $this.data('pd'),
               id = $this.data('id'),
               vid = $this.data('vid'),
               product = $this.parents('.cs_pr'),
               image = product.find('.main-img'),
               id_img = image.attr('data-id'),
               href = product.find('.product-title>a').attr('href');

            $this.parents('.swatch__list_js').find('.current-swatch').removeClass('current-swatch');
            $this.addClass('current-swatch');

            if( id  == id_img ) return;
               product.addClass('cs-swatched');

             if ($this.hasClass('loaded_swatch')) {
                image.addClass(hide_ic_lz);
             } else {
                image.removeClass(hide_ic_lz);
             }

             $this.addClass('loaded_swatch');
            image.attr('data-bgset', imagebg).attr('data-id', id);
            if ( cs_settings.pr_curent == '1') return;
            product.find('a').attr('href',href.split('?variant=')[0]+'?variant='+vid);
            product.find('.cs_add_qv').attr('data-id',vid);
       };

       body.on('click', '.cs_swatch_on_bg:not(.current-swatch)', function() {
          if (!touchevents) return;
            swatches_js($(this));

       });

      if (touchevents) return;
      body.hoverIntent({
         selector: '.cs_swatch_on_bg',
         sensitivity: 6,
         interval: 100,
         timeout: 100,
         over:function(t){
            swatches_js( $(this) );
         },
         out: function(){}
      });

    };

    cleverSopify.ideaIntent = function() {

      if (!yesHover) return;
      body.find("li.idea_intent").each(function() {
          var $this = $(this);
          $this.hoverIntent({
          sensitivity: 3,
          interval: 70,
          timeout: 70,
              over: function(ever) {
                  $this.addClass("current_intent");
              },
              out: function() {
                  $this.removeClass("current_intent")
              }
          })
      });

    };


   cleverSopify.cartPosDropdown = function() {

      if (!body.hasClass('cart_pos_dropdown') || touchevents || body.hasClass('template-cart')) return;
        var $cart = $('#cs_cart_canvas'),
            $icon_cart = $('.cart_pos_dropdown .icon_cart'),
            $window = $(window),
            fullHeight = 60,
            windowHeight = $window.height(),
            windowWidth = $window.width(),
            offsetTop = $icon_cart.offset().top,
            right = (windowWidth - ($icon_cart.offset().left + $icon_cart.outerWidth())),
            outerH = $icon_cart.outerHeight(),
            top = offsetTop + 40;

          $cart.css({
               'position' : 'absolute',
               'top' : top,
               'right' : right
          });

          if (offsetTop < windowHeight) {
           var fullHeight = 100 - (offsetTop+40) / (windowHeight / 100);
          }

        $icon_cart.hoverIntent({
           sensitivity: 6,
           interval: 100,
           timeout: 100,
           over:function(t){
              top = $icon_cart.offset().top + 40;
              body.addClass('oped_dropdown_cart');
              $cart.css("top", top).addClass("current_hover");
           },
           out: function(){
            if ($cart.is(":hover")) return;
              body.removeClass('oped_dropdown_cart');
              $cart.removeClass("current_hover");
           }
        });

        $cart.on("mouseleave", function () {
            body.removeClass('oped_dropdown_cart');
            $cart.removeClass("current_hover");
        });
   };

    cleverSopify.headerCategoriesMenu = function () {

      if (!touchevents || $('#cat_shopify').length == 0 ) return;

      var cat_shop = '#shopify-section-cat_shop',
        button = '#shopify-section-cat_shop .cat_nav_js',
        catsUl = '#cat_shopify',
        time = 200;

      body.on('click', cat_shop+' .cat_nav_js', function (e) {
        e.preventDefault();

        if (isOpened()) {
          closeCats();
        } else {
          openCats();
        }
      });

      body.on('click', catsUl+' .menu-item-has-children>a', function (e) {
        e.preventDefault();
        var sublist = $(this).parent().find('> .sub-menu');
        if (sublist.hasClass('child-open')) {
          $(this).removeClass("act-icon");
          sublist.slideUp(time).removeClass('child-open');
        } else {
          $(this).addClass("act-icon");
          sublist.slideDown(time).addClass('child-open');
        }
      });

      var isOpened = function () {
        return $(catsUl).hasClass('cat_opened');
      };

      var openCats = function () {
        $(catsUl).addClass('cat_opened').stop().slideDown(time);
        $(button).addClass('btn_open');

      };

      var closeCats = function () {
        $(catsUl).removeClass('cat_opened').stop().slideUp(time);
        $(button).removeClass('btn_open');
      };

    };

    cleverSopify.popupMFP = function () {
      body.on('click', '[data-opencs]', function (e) {
          var $this = $(e.currentTarget),
              html = $("html"),
              datas = $this.data(),
              id = datas.opencs,
              color = datas.color,
              bg = datas.bg,
              position = datas.pos,
              ani = datas.ani || 'has_cscanvas',
              remove = datas.remove,
              cl = datas.class,
              close = datas.close || false,
              focuslast = datas.focuslast || false,
              focus = $this.attr("data-focus"),
              YOffset = window.pageYOffset,
              height = window.height - $('#shopify-section-header_banner').outerHeight() - $('.csheader_wrapper').outerHeight();

          var cs_scroll = function () {
            if( !YOffset) return;
            $('html, body').scrollTop(YOffset);
          }
          $this.addClass("current_clicked");
           $.magnificPopup.open({
              items: {
                  src: id,
                  type: "inline",
                  tLoading: '<div class="loading-spin dark"></div>'
              },
              tClose: cs_settings.close,
              removalDelay: 300,
              closeBtnInside: close,
              focus: focus,
              autoFocusLast: focuslast,
              callbacks: {
                  beforeOpen: function() {
                      this.st.mainClass = ani + " " + color + " " + ani+"_" + position;
                  },
                  open: function() {
                      html.addClass(ani);
                      html.addClass(ani+"_" + position);
                      cl && $(".mfp-content").addClass(cl);
                      bg && $(".mfp-bg").addClass(bg);
                        body.on('click', '.close_pp', function(e) {
                           e.preventDefault();
                           $.magnificPopup.close();
                        });
                        cs_scroll();



                  },
                  beforeClose: function() {
                      html.removeClass(ani);

                  },
                  afterClose: function() {
                      html.removeClass(ani+"_" + position);
                      $(".current_clicked").removeClass("current_clicked");
                      remove && $(id).removeClass("mfp-hide");
                  }
              }
          });
         e.preventDefault()
      })
    };

    // Product quick view
    cleverSopify.initQuickView = function () {
      body.on('click', '.js_add_qv', function (e) {
         e.preventDefault();
         e.stopPropagation();

         if (designMode) return;
         var btn = $(this),
             res = null, ntid =
             btn.attr('data-id'),
             href = btn.attr('href');
         if(sp_cs_storage) {res = sessionStorage.getItem('qv'+ntid)}
         if (res !== null) {
            btn.addClass('loading');
            if ($.magnificPopup.instance.isOpen) {
               $.magnificPopup.close();
               setTimeout(function(){  quickview_js(false,res,btn,ntid,href); }, $.magnificPopup.instance.st.removalDelay+10);
            } else {
              quickview_js(false,res,btn,ntid,href);
            }
         } else {
            var a = (href.indexOf('?variant=')  >= 0) ? '&' : '/?';
            $.ajax({
               beforeSend: function () {
                  btn.addClass('loading');
               },
               url: href+a+'view=quick-view',
               success: function (data) {
                  if ($.magnificPopup.instance.isOpen) {
                     $.magnificPopup.close();
                     setTimeout(function(){  quickview_js(true,data,btn,ntid,href); }, $.magnificPopup.instance.st.removalDelay+10);
                  } else {
                    quickview_js(true,data,btn,ntid,href);
                  }
               },
               complete: function () {
                  $('.loader').remove();
                  btn.removeClass('loading');
               }
            })
         }
      });

      var quickview_js = function (bl,dt,btn,ntid,href) {
         $.magnificPopup.open({
            items: {
               src: '<div class="mfp-with-anim popup-quick-view" id="content_quickview">' + dt + '</div>', // can be a HTML string, jQueryCS object, or CSS selector
               type: 'inline'
            },
            tClose: cs_settings.close,
            removalDelay: 500, //delay removal by X to allow out-animation
            callbacks: {
               beforeOpen: function () {
                  this.st.mainClass = 'mfp-move-horizontal';
               },
               open: function () {

                  var el = $('.cs_carousel_qv'),option = el.attr("data-flickity") || '{}';
                  el.flickity(JSON.parse(option));

                  body.addClass('open_csqv');
                  cleverSopify.ATC_animation('#callBackVariant_qv .single_add_to_cart_button');
                  cleverSopify.InitCountdown_pr('#cs_countdow_qv');
                    var txt_stock = '#cs_stock_qv',
                      $cs_stock = $(txt_stock),
                      qty_cur = $cs_stock.data('cur'),
                      qty_mess = $cs_stock.data('st'),
                      ck_inventory = $cs_stock.data('qty');
                  if ((qty_mess == 1 || qty_mess == 3) && qty_cur < ck_inventory && qty_cur > 0) {
                    cleverSopify.progressbar(txt_stock,qty_cur);
                  } else {
                    cleverSopify.progressbar(txt_stock);
                  }
                  cleverSopify.delivery_order('#delivery_qv');
                  cleverSopify.real_time('#counter_qv');
                  cleverSopify.flashSold('#sold_qv');
                  body.trigger('refresh_currency');

                  if(typeof addthis !== 'undefined') {addthis.layers.refresh()}

                  if(sp_cs_storage && bl) {
                    sessionStorage.setItem('qv'+ntid, dt)
                  }

                  $('#content_quickview .entry-title a, #content_quickview .detail_link').attr("href",href);
                  btn.removeClass('loading');

                  cleverSopify.DropdownPicker();
                  cleverSopify.review();
                  if ($('#content_quickview .buy_qv_true').length > 0) {
                    Shopify.PaymentButton.init();
                  }
                  $('#content_quickview .lazypreload.cs_pre_img').addClass('lazyload');

                  if (!$('#ProductJson-template_qv').html()) {
                    return;
                  }

                  var productJson = JSON.parse($('#ProductJson-template_qv').html()),
                    incomingJson = JSON.parse($('#ProductJson-incoming_qv').html()),
                    IdSelect = '#product-select_qv',NtId = '#cs_select_qv_',selector = '#cart-form_qv',callBackVariant = '#callBackVariant_qv',prefix='_qv',
                    i,variant,Arr_MD = [];

                    productJson.ck_so_un = incomingJson.ck_so_un;
                    productJson.cssoldout = incomingJson.cssoldout;
                    productJson.unvariants = incomingJson.unvariants;
                    productJson.remove_soldout = incomingJson.remove_soldout;
                    productJson.size_avai = incomingJson.size_avai;
                    productJson.tt_size_avai = incomingJson.tt_size_avai;

                  for (i in incomingJson.variants) {
                    variant = incomingJson.variants[i];
                    productJson.variants[i].incoming = variant.incoming;
                    productJson.variants[i].next_incoming_date = variant.next_incoming_date;
                    productJson.variants[i].inventory_quantity = variant.inventory_quantity;
                    Arr_MD.push(variant.mdid);
                  }
                  cleverSopify.Ntproduct_switch('.variations_form_qv',Arr_MD,productJson,selector,IdSelect,NtId,callBackVariant,prefix);
                  if (cs_settings.pr_curent !== "1" || $('#cart-form_qv .is-selected-cs').length > 0 ) {
                      $('#cs_select_qv_1 .is-selected-cs, #cs_select_qv_2 .is-selected-cs').addClass('is-selected').removeClass('is-selected-cs');
                      $('#cs_select_qv_0 .is-selected-cs').click().removeClass('is-selected-cs');

                      if (!use_vimg) return;
                      $('#cs_select_qv_1 .is-selected,#cs_select_qv_2 .is-selected').removeClass('is-selected').click();
                  }
               },
               close: function () {
                  $('#content_quickview').empty();
                  body.removeClass('open_csqv');
                  cleverSopify.DropdownPicker();
               }
            },
         });
      }

    };

    // QuickShop
    cleverSopify.quickShop = function () {
      var clicked_ed_js = 'clicked_ed_js';
      body.on('click', '.js__qs', function (e) {
         e.preventDefault();
         e.stopPropagation();

         if (designMode) return;
         var btn = $(this),res = null, ntid = btn.attr('data-id'), href = btn.attr('href');
         if(sp_cs_storage) {res = sessionStorage.getItem('qs'+ntid)}
         if (res !== null) {
            btn.addClass('loading '+clicked_ed_js);
            if ($.magnificPopup.instance.isOpen) {
               $.magnificPopup.close();
               setTimeout(function(){  quickshop_js(false,res,btn,ntid,href); }, $.magnificPopup.instance.st.removalDelay+10);
            } else {
              quickshop_js(false,res,btn,ntid,href);
            }
         } else {
            var a = (href.indexOf('?variant=')  >= 0) ? '&' : '/?';
            $.ajax({
               beforeSend: function () {
                  btn.addClass('loading '+clicked_ed_js);
               },
               url: href+a+'view=quick-shop',
               success: function (data) {
                  if ($.magnificPopup.instance.isOpen) {
                     $.magnificPopup.close();
                     setTimeout(function(){  quickshop_js(true,data,btn,ntid,href); }, $.magnificPopup.instance.st.removalDelay+10);
                  } else {
                    quickshop_js(true,data,btn,ntid,href);
                  }
               },
               complete: function () {
                  $('.loader').remove();
                  btn.removeClass('loading');
               }
            })
         }
      });

      var quickshop_js = function (bl,dt,btn,ntid,href) {
       $.magnificPopup.open({
          items: {
             src: '<div class="mfp-with-anim pp_qs" id="content_quickview">' + dt + '</div>', // can be a HTML string, jQueryCS object, or CSS selector
             type: 'inline'
          },
          tClose: cs_settings.close,
          removalDelay: 500, //delay removal by X to allow out-animation
          callbacks: {
             beforeOpen: function () {
                this.st.mainClass = 'mfp-move-vertical';
             },
             open: function () {
                  var el = $('.cs_carousel_qs'),option = el.attr("data-flickity") || '{}';
                  el.flickity(JSON.parse(option));
                body.addClass('open_csqs');

                if(sp_cs_storage && bl) {sessionStorage.setItem('qs'+ntid, dt)}
                btn.removeClass('loading');

                cleverSopify.DropdownPicker();
                cleverSopify.review();
                if ($('#content_quickview .buy_qs_true').length > 0) {
                  Shopify.PaymentButton.init();
                }
                $('#content_quickview .lazypreload.cs_pre_img').addClass('lazyload');

                if (!$('#ProductJson-template_qs').html()) {
                  return;
                }

                var productJson = JSON.parse($('#ProductJson-template_qs').html()),
                  incomingJson = JSON.parse($('#ProductJson-incoming_qs').html()),
                  IdSelect = '#product-select_qs',NtId = '#cs_select_qs_',selector = '#cart-form_qs',callBackVariant = '#callBackVariant_qs',prefix='_qs',
                  i,variant,Arr_MD = [];

                  productJson.ck_so_un = incomingJson.ck_so_un;
                  productJson.cssoldout = incomingJson.cssoldout;
                  productJson.unvariants = incomingJson.unvariants;
                  productJson.remove_soldout = incomingJson.remove_soldout;
                  productJson.size_avai = incomingJson.size_avai;
                  productJson.tt_size_avai = incomingJson.tt_size_avai;

                for (i in incomingJson.variants) {
                  variant = incomingJson.variants[i];
                  productJson.variants[i].incoming = variant.incoming;
                  productJson.variants[i].next_incoming_date = variant.next_incoming_date;
                  productJson.variants[i].inventory_quantity = variant.inventory_quantity;
                  Arr_MD.push(variant.mdid);
                }

                cleverSopify.Ntproduct_switch('.variations_form_qs',Arr_MD,productJson,selector,IdSelect,NtId,callBackVariant,prefix);
                if (cs_settings.pr_curent !== "1" || $('#cart-form_qs .is-selected-cs').length > 0 ) {
                    $('#cs_select_qs_1 .is-selected-cs, #cs_select_qs_2 .is-selected-cs').addClass('is-selected').removeClass('is-selected-cs');
                    $('#cs_select_qs_0 .is-selected-cs').click().removeClass('is-selected-cs');

                    if (!use_vimg) return;
                    $('#cs_select_qs_1 .is-selected,#cs_select_qs_2 .is-selected').removeClass('is-selected').click();
                }
             },
             close: function () {
                $('.'+clicked_ed_js).removeClass(clicked_ed_js);
                $('#content_quickview').empty();
                body.removeClass('open_csqs');
                cleverSopify.DropdownPicker();
             }
          },
       });
      };

    };



    cleverSopify.mobileNav = function () {

      var mobileNav = $("#cs_menu_canvas,#nav_header7");

      mobileNav.on("click", ".menu-item-has-children.only_icon_false>a", function (e) {
        e.preventDefault();
        e.stopPropagation();

        var _this = $(this), _parent = _this.parent();
        ClickToActive(_this, _parent);

      });

      mobileNav.on("click", ".menu-item-has-children .nav_link_icon", function (e) {
        e.preventDefault();
        e.stopPropagation();

        var _this = $(this), _parent = _this.parent().parent();
        ClickToActive(_this, _parent);

      });

      var ClickToActive = function (_this,_parent) {

        if (_parent.hasClass("cs_opended")) {
         _parent.removeClass("cs_opended").children("ul").slideUp(200);
        } else {
          _parent.addClass("cs_opended").children("ul").slideDown(200);
        }
      };

      mobileNav.on('click', '.mb_nav_tabs>div', function () {
        if ($(this).hasClass('active')) return;

        var _this = $(this), menuID = _this.data('id');
        _this.parent().find('.active').removeClass('active');
        _this.addClass('active');
        $('.mb_nav_tab').removeClass('active');
        $(menuID).addClass('active');
      });

    };

    // video html5
    cleverSopify.InitHTMLVideo = function () {
      //https://developer.mozilla.org/en-US/docs/Web/Guide/Events/Media_events
      if ($('.vid_cs_js').length == 0 || !Modernizr.video) return;

      $('.vid_cs_js').each(function() {
         var _this = $(this),
             _img = _this.parent().find('.img_vid_js');
        _this.addClass('lazyload');
          _this.on('lazyloaded', function() {
            _this[0].play();
            _this.addClass('vid_ready');
            _img.addClass('lazyload');
          });

          _this.on('playing', function() {
            _img.remove();
          });

      });
    };

    // Open video in popup
    cleverSopify.InitPopupVideo = function () {
      if ($('.cs_mfp_video').length == 0) return;

      $('.cs_mfp_video').magnificPopup({
         disableOn: 0,
         type: 'iframe',
         tClose: cs_settings.close,
         iframe: {
            markup: '<div class="mfp-iframe-scaler pr">'+
                  '<div class="mfp-close"></div>'+
                  '<iframe class="mfp-iframe" frameborder="0" allowfullscreen></iframe>'+
                '</div>', // HTML markup of popup, `mfp-close` will be replaced by the close button

            patterns: {
                youtube: {
                  index: 'youtube.com/', // String that detects type of video (in this case YouTube). Simply via url.indexOf(index).
                  id: 'v=',
                  src: '//www.youtube.com/embed/%id%?autoplay=1' // URL that will be set as a source for iframe.
                },
                vimeo: {
                  index: 'vimeo.com/',
                  id: '/',
                  src: '//player.vimeo.com/video/%id%?autoplay=1'
                }
            },
            srcAction: 'iframe_src', // Templating object key. First part defines CSS selector, second attribute. "iframe_src" means: find "iframe" and set attribute "src".
         }
      });
    };

    // Open HTML in popup
    cleverSopify.InitPopupHTML = function () {
      if ($('.cs_mfp_html').length == 0) return;

      body.on('click', '.cs_mfp_html', function (e) {
          $.magnificPopup.open({
            items: {
              src: $(this).data('mfp')
            },
            type: 'iframe'
          });

        return false; //for good measure
        e.preventDefault();
        e.stopPropagation();
      });
    };

    cleverSopify.preloadImages = function(arrayOfImages) {
        $(arrayOfImages).each(function(){
            $('<img/>')[0].src = this;
        });
    };

    // 360 video
    cleverSopify.Init360Video = function () {
      if ($('.cs_mfp_360').length == 0) return;

      var threesixty,pr_id;

      $('.cs_mfp_360').magnificPopup({
          items: {
            src: '#pr_360_mfp'
          },
         type: 'inline',
         tClose: cs_settings.close,
         mainClass: 'mfp-fade',
         removalDelay: 160,
         disableOn: false,
         preloader: false,
         fixedContentPos: false,
         callbacks: {
           beforeOpen: function() {},
           open: function () {
            if ($('.threesixty.doned').length > 0) return;

              var NTsettingspr = JSON.parse($('#NTsettingspr__ppr').html());
                 pr_id = NTsettingspr.ProductID;
              threesixty = $('.threed_id_'+pr_id).ThreeSixty({
                  totalFrames: NTsettingspr.totalFrames,
                  endFrame: NTsettingspr.endFrame,
                  currentFrame: 1,
                  framerate: NTsettingspr.framerate,
                  autoplayDirection: NTsettingspr.autoplayDirection,
                  imgList: ".threesixty_imgs",
                  progress: ".spinner",
                  imgArray: NTsettingspr.imgArray,
                  height: NTsettingspr.height,
                  width: NTsettingspr.width,
                  responsive: true,
                  navigation: true
              });
              $('.threed_id_'+pr_id).addClass('doned');
            },
            beforeClose: function () {
              threesixty.stop();
              $('.nav_bar_stop').removeClass("nav_bar_stop").addClass("nav_bar_play");
            },
            close: function () {}
         },

      });

    };

    cleverSopify.add_loading = function () {
      body.on('click', '.js_add_ld:not(.jscl_ld)', function(e) {

          $ld.trigger( "ld_bar_star" );
          setTimeout(function(){ $ld.trigger( "ld_bar_60" ) }, 250);
          setTimeout(function(){ $ld.trigger( "ld_bar_80" ) }, 300);
          setTimeout(function(){ $ld.trigger( "ld_bar_90" ) }, 400);
          setTimeout(function(){ $ld.trigger( "ld_bar_94" ) }, 500);
          setTimeout(function(){ $ld.trigger( "ld_bar_end" ) }, 1000);
      });
    };

    cleverSopify.footerCollapse = function () {
        if ( $(window).width() > 767 || $('.footer_collapse_true').length == 0 ) return;

        $('.footer_collapse_true .widget-title').off('click').on('click', function () {
          var $title = $(this);
          var $widget = $title.parent();
          var $content = $widget.find('> .widget_footer');

          if ($widget.hasClass('footer_opened')) {
            $widget.removeClass('footer_opened');
            $content.stop().slideUp(200);
          } else {
            $widget.addClass('footer_opened');
            $content.stop().slideDown(200);
          }
        });

    };


    cleverSopify.backToTop = function () {
      var el = $('#cs_backtop');
      if ( ( $(window).width() < 768 && cs_settings.backtop !='3' ) || el.length == 0 ) return;

      var debounce_timer;
      $(window).scroll(function() {
        if(debounce_timer) {window.clearTimeout(debounce_timer);}

        debounce_timer = window.setTimeout(function() {
          if ($(this).scrollTop() > cs_settings.scrollTop) {
              el.addClass('bkt_show');
          } else {
              el.removeClass('bkt_show');
          }
        }, 40);
     });

      //Click event to scroll to top
      el.on('click', function () {
          $('html, body').animate({
              scrollTop: 0
          }, 800);
          return false;
      });
    };

    cleverSopify.currencyForm = function () {

      if ( $('#CurrencyLangSelector').length == 0 ) return;


       function _submitFormCurrencyLang(value,disclosureInput) {
          $(disclosureInput).val(value);
          $('#CurrencyLangSelector').submit();
       };

       if ($('#CurrencySelector').length > 0) {
           var _Selector = '.languages a.lang-item,.currencies a.currency-item';
       } else {
           var _Selector = '.languages a.lang-item';
       }

        body.on("click",_Selector,function(e) {

           e.preventDefault();
           var $this = $(this);
           if ($this.hasClass('selected')) return;

           if ($this.hasClass('lang-item')) {
             var _parent = '.languages',
                 _child = '.languages .lang-item',
                 _input = '#LocaleSelector';

           } else {
             var _parent = '.currencies',
                 _child = '.currencies .currency-item',
                 _input = '#CurrencySelector';
           }

          var newCurrency = $this.attr('data-currency'),
              oldCurrency = $(_parent+' a.selected').first().attr("data-currency") || t_shop_currency;
          $(_parent+' .current').text($this.text()).removeClass('flagscs-'+oldCurrency).addClass('flagscs-'+newCurrency);
          $(_child).removeClass('selected');
          $(_parent+' a[data-currency=' + newCurrency + ']').addClass('selected');
          _submitFormCurrencyLang(newCurrency,_input);
          $ld.trigger( "ld_bar_star" );
          setTimeout(function(){ $ld.trigger( "ld_bar_60" ) }, 250);
          setTimeout(function(){ $ld.trigger( "ld_bar_80" ) }, 300);
          setTimeout(function(){ $ld.trigger( "ld_bar_90" ) }, 380);
          setTimeout(function(){ $ld.trigger( "ld_bar_94" ) }, 500);
          setTimeout(function(){ $ld.trigger( "ld_bar_end" ) }, 1000);

        });

       var StorageCurrency = cleverSopify.StorageCurrency();
       if (!cs_settings.currency_visitor || StorageCurrency != null || navigator.userAgent.match(/bot|spider/i) ) return;

        var currencyUpdate = function (currency) {
          if (sp_cs_storage) {localStorage.setItem('CSCurrency', currency)}
          $('.currencies a[data-currency="'+currency+'"]:first').trigger('click');
        };
       var arrayCurrency ={AF:"AFN",AX:"EUR",AL:"ALL",DZ:"DZD",AS:"USD",AD:"EUR",AO:"AOA",AI:"XCD",AQ:"",AG:"XCD",AR:"ARS",AM:"AMD",AW:"AWG",AU:"AUD",AT:"EUR",AZ:"AZN",BS:"BSD",BH:"BHD",BD:"BDT",BB:"BBD",BY:"BYN",BE:"EUR",BZ:"BZD",BJ:"XOF",BM:"BMD",BT:"BTN",BO:"BOB",BA:"BAM",BW:"BWP",BV:"NOK",BR:"BRL",IO:"USD",BN:"BND",BG:"BGN",BF:"XOF",BI:"BIF",KH:"KHR",CM:"XAF",CA:"CAD",CV:"CVE",KY:"KYD",CF:"XAF",TD:"XAF",CL:"CLP",CN:"CNY",CX:"AUD",CC:"AUD",CO:"COP",KM:"KMF",CG:"XAF",CD:"CDF",CK:"NZD",CR:"CRC",CI:"XOF",HR:"HRK",CU:"CUP",CY:"EUR",CZ:"CZK",DK:"DKK",DJ:"DJF",DM:"XCD",DO:"DOP",EC:"USD",EG:"EGP",SV:"USD",GQ:"XAF",ER:"ERN",EE:"EUR",ET:"ETB",FK:"FKP",FO:"DKK",FJ:"FJD",FI:"EUR",FR:"EUR",GF:"EUR",PF:"XPF",TF:"EUR",GA:"XAF",GM:"GMD",GE:"GEL",DE:"EUR",GH:"GHS",GI:"GIP",GR:"EUR",GL:"DKK",GD:"XCD",GP:"EUR",GU:"USD",GT:"GTQ",GG:"GBP",GN:"GNF",GW:"XOF",GY:"GYD",HT:"HTG",HM:"AUD",VA:"EUR",HN:"HNL",HK:"HKD",HU:"HUF",IS:"ISK",IN:"INR",ID:"IDR",IR:"IRR",IQ:"IQD",IE:"EUR",IM:"GBP",IL:"ILS",IT:"EUR",JM:"JMD",JP:"JPY",JE:"GBP",JO:"JOD",KZ:"KZT",KE:"KES",KI:"AUD",KR:"KRW",KW:"KWD",KG:"KGS",LA:"LAK",LV:"EUR",LB:"LBP",LS:"LSL",LR:"LRD",LY:"LYD",LI:"CHF",LT:"EUR",LU:"EUR",MO:"MOP",MK:"MKD",MG:"MGA",MW:"MWK",MY:"MYR",MV:"MVR",ML:"XOF",MT:"EUR",MH:"USD",MQ:"EUR",MR:"MRU",MU:"MUR",YT:"EUR",MX:"MXN",FM:"USD",MD:"MDL",MC:"EUR",MN:"MNT",ME:"EUR",MS:"XCD",MA:"MAD",MZ:"MZN",MM:"MMK",NA:"NAD",NR:"AUD",NP:"NPR",NL:"EUR",AN:"",NC:"XPF",NZ:"NZD",NI:"NIO",NE:"XOF",NG:"NGN",NU:"NZD",NF:"AUD",MP:"USD",NO:"NOK",OM:"OMR",PK:"PKR",PW:"USD",PS:"ILS",PA:"PAB",PG:"PGK",PY:"PYG",PE:"PEN",PH:"PHP",PN:"NZD",PL:"PLN",PT:"EUR",PR:"USD",QA:"QAR",RE:"EUR",RO:"RON",RU:"RUB",RW:"RWF",BL:"EUR",SH:"SHP",KN:"XCD",LC:"XCD",MF:"EUR",PM:"EUR",VC:"XCD",WS:"WST",SM:"EUR",ST:"STN",SA:"SAR",SN:"XOF",RS:"RSD",SC:"SCR",SL:"SLL",SG:"SGD",SK:"EUR",SI:"EUR",SB:"SBD",SO:"SOS",ZA:"ZAR",GS:"GBP",ES:"EUR",LK:"LKR",SD:"SDG",SR:"SRD",SJ:"NOK",SZ:"SZL",SE:"SEK",CH:"CHF",SY:"SYP",TW:"TWD",TJ:"TJS",TZ:"TZS",TH:"THB",TL:"USD",TG:"XOF",TK:"NZD",TO:"TOP",TT:"TTD",TN:"TND",TR:"TRY",TM:"TMT",TC:"USD",TV:"AUD",UG:"UGX",UA:"UAH",AE:"AED",GB:"GBP",US:"USD",UM:"USD",UY:"UYU",UZ:"UZS",VU:"VUV",VE:"VEF",VN:"VND",VG:"USD",VI:"USD",WF:"XPF",EH:"MAD",YE:"YER",ZM:"ZMW",ZW:"ZWD"};

       if (cs_currency) {
          var data = JSON.parse(cs_currency),currency;
              try {
                 currency = data.currency.handle
              }
              catch(err) {
                 currency = arrayCurrency[data.countryCode] || arrayCurrency[data.country] || data.currency;
              }
          currencyUpdate(currency);
       } else {

          var params = {
             type: 'get',
             url: 'https://extreme-ip-lookup.com/json',
             dataType: "json",
             success: function (data) {
                if (data.status == "success") {
                  if (sp_cs_storage) { localStorage.setItem('cs_currency', JSON.stringify(data))}
                  currencyUpdate(arrayCurrency[data.countryCode]);
                } else {
                  $.ajax(params_2)
                }
             },
             error: function (XMLHttpRequest, textStatus) {
                $.ajax(params_2)
             }
          };

          var params_2 = {
             type: 'get',
             url: 'https://ipinfo.io/json',
             dataType: "json",
             success: function (data) {
                if (sp_cs_storage) { localStorage.setItem('cs_currency', JSON.stringify(data))}
                currencyUpdate(arrayCurrency[data.country]);
             }
          };

          $.ajax({
             type: 'get',
             url: '/browsing_context_suggestions.json?source=geolocation_recommendation&currency[enabled]=true&language[enabled]=true',
             dataType: "json",
             success: function (data) {
              try {
                 var arrSuggest = data.suggestions[0].parts;
                 if (sp_cs_storage) { localStorage.setItem('cs_currency', JSON.stringify(arrSuggest))}
                 currencyUpdate(arrSuggest.currency.handle);
              }
              catch(err) {
                $.ajax(params)
              }
             },
             error: function (XMLHttpRequest, textStatus) {
                $.ajax(params)
             }
          });

        }
      };

      cleverSopify.stickyFooter = function () {

        if ($('.footer_sticky_true').length == 0 || $(window).width() <= 1024) return;
          var $footer = $('#cs_footer'),
            $page = $('#cs_content'),
            $window = $(window);

          if ($('.clever_prefooter').length > 0) {
            $page = $('.clever_prefooter');
          }

          var footerOffset = function () {
            $page.css({
              marginBottom: $footer.outerHeight()
            });
          };

          $window.on('resize', footerOffset);

          footerOffset();
          body.addClass('calc_footer_sticky');

          //Safari fix
          if (!$('html').hasClass('browser-Safari')) return;
          var footerSafariFix = function () {
            var windowScroll = $window.scrollTop();
            var footerOffsetTop = $(document).outerHeight() - $footer.outerHeight();

            if (footerOffsetTop < windowScroll + $footer.outerHeight() + $window.outerHeight()) {
              $footer.addClass('visible_footer');
            } else {
              $footer.removeClass('visible_footer');
            }
          };

          footerSafariFix();
          $window.on('scroll', footerSafariFix);
      };


      cleverSopify.NewsletterPopup = function () {

        if ($('.popup_new_wrap').length == 0 || ($('.mobile_new_false').length > 0 && $(window).width() < 768) || (Cookies.get('clever_age_verify') != 'confirmed' && $('.popup_age_wrap').length > 0) ) return;
        var popup = $('.popup_new_wrap'),
          stt = popup.data('stt'),
          pp_version = stt.pp_version,
          shown = false,
          pages = Cookies.get('clever_shown_pages');

          var showPopup = function () {
            $.magnificPopup.open({
              items: {
                src: '#shopify-section-newsletter_pp .popup_new_wrap'
              },
              type: 'inline',
              removalDelay: 500, //delay removal by X to allow out-animation
              tClose: cs_settings.close,
              callbacks: {
                beforeOpen: function () {
                  this.st.mainClass ='mfp-move-horizontal new_pp_wrapper';
                },
                open: function () {
                  // Will fire when this exact popup is opened
                  // this - is Magnific Popup object
                },
                close: function () {
                  Cookies.set('clever_popup_' + pp_version, 'shown', { expires: stt.day_next, path: '/' });
                }
                // e.t.c.
              }
            });
          };

          var showPopup2 = function () {
              if ($.magnificPopup.instance.isOpen) {
                 $.magnificPopup.close();
                 setTimeout(function(){ showPopup(); }, $.magnificPopup.instance.st.removalDelay+10);
              } else {
                showPopup();
              }
          };

          $('.clever_open_newsletter').on('click', function (e) {
            e.preventDefault();
            showPopup2();
          });

          popup.on('open_newsletter', function () {
            showPopup2();
          });

          if (designMode) return;

          if (!pages) pages = 0;
          if (pages < stt.number_pages) {
            pages++;
            Cookies.set('clever_shown_pages', pages, { expires: stt.day_next, path: '/' });
            return false;
          }

          if (Cookies.get('clever_popup_' + pp_version) != 'shown') {
            if (stt.after == 'scroll') {
              $(window).scroll(function () {
                if (shown) return false;
                if ($(document).scrollTop() >= stt.scroll_delay) {
                  showPopup2();
                  shown = true;
                }
              });
            } else {
              setTimeout(function () {
                showPopup2();
              }, stt.time_delay);
            }
          }
      };

      // Age verify.
      cleverSopify.ageVerify = function () {
          if ( $('.popup_age_wrap').length == 0 || ( !designMode && Cookies.get('clever_age_verify') == 'confirmed') ) return;

          var popup = $('.popup_age_wrap'),
          stt = popup.data('stt'),
          age_limit = stt.age_limit,
          date_of_birth = stt.date_of_birth,
          day_next = stt.day_next;

          var showPopup = function () {
            $.magnificPopup.open({
              items: {
                src: '#shopify-section-age-verify .popup_age_wrap'
              },
              type: 'inline',
              closeOnBgClick: false,
              closeBtnInside: false,
              showCloseBtn: false,
              enableEscapeKey: false,
              removalDelay: 500,
              tClose: cs_settings.close,
              callbacks: {
                beforeOpen: function () {
                  this.st.mainClass ='mfp-move-horizontal age_pp_wrapper';
                },
              }
            });
          };

          if (!designMode) {
            showPopup();
          }
          popup.on('open_age_pp', function () {
            showPopup();
          })

          $('.age_verify_allowed').on('click', function(){

            if (date_of_birth) {
               var year =  parseInt($('#ageyear').val()),
                   month = parseInt($('#agemonth').val()),
                   day =   parseInt($('#ageday').val()),
                   theirDate = new Date((year + age_limit), month, day),
                   today = new Date;

               if ((today.getTime() - theirDate.getTime()) < 0) {
                 popup.addClass('animated shake');
                  window.setTimeout(function(){
                    popup.removeClass('animated shake');
                  }, 1000);
               } else {
                Cookies.set('clever_age_verify', 'confirmed', { expires: parseInt( day_next ), path: '/' });
                $.magnificPopup.close();
               }
            } else {
              Cookies.set('clever_age_verify', 'confirmed', { expires: parseInt( day_next ), path: '/' });
              $.magnificPopup.close();
            }

          });

          $('.age_verify_forbidden').on('click', function(){
            popup.addClass('active_forbidden');
          });
      };

      // Cookies law.
      cleverSopify.cookiesLawPP = function () {

        var popup = $('.popup_cookies_wrap'),
            popup_parent = popup.parent(),
            stt = popup.data('stt');
            try {
              var pp_version = stt.pp_version;
            }
            catch(err) {
              var pp_version = 1994;
            }
        if ( (!designMode && Cookies.get('clever_cookies_' + pp_version) == 'accepted') || popup.length == 0 ) return;

        var showPopup = function () {
          popup_parent.removeClass('pp_onhide').addClass('pp_onshow');
          popup.on('click', '.pp_cookies_accept_btn', function (e) {
            e.preventDefault();
            acceptCookies();
          });
        };

        if (!designMode) {
          setTimeout(function () {
          showPopup();
          }, 2500);
        }

        popup.on('open_cookies_pp', function () {
          showPopup();
        })

        var acceptCookies = function () {
          popup_parent.removeClass('pp_onshow').addClass('pp_onhide');
          Cookies.set('clever_cookies_' + pp_version, 'accepted', { expires: stt.day_next, path: '/' });
        };

      };

      cleverSopify.PromoPrPopup = function () {
        var pp_version = 1;
        if ($('.js_lz_pppr').length == 0 || window_w < 1025 || !yesHover || (Cookies.get('clever_age_verify') != 'confirmed' && $('.popup_age_wrap').length > 0) || (!designMode && Cookies.get('clever_prpr_pp_' + pp_version) == 'shown')) return;

          var popup = $('.popup_prpr_wrap');
          var showPopup = function () {
            var stt = $('.popup_prpr_wrap').data('stt');
            $.magnificPopup.open({
              items: {
                src: '#shopify-section-promo-pr-pp .popup_prpr_wrap'
              },
              type: 'inline',
              removalDelay: 500, //delay removal by X to allow out-animation
              tClose: cs_settings.close,
              callbacks: {
                beforeOpen: function () {
                  this.st.mainClass ='mfp-move-horizontal prpr_pp_wrapper';
                },
                open:function () {
                  var $el = $('.popup_prpr_wrap .js_carousel');
                  cleverSopify.refresh_flickity($el);
                  cleverSopify.flickityResposition(false,$el);
                  cleverSopify.InitCountdown();
                  cleverSopify.review();
                  body.trigger('refresh_currency');
                  $(document).off('mouseleave.registerexit');
                  // Will fire when this exact popup is opened
                  // this - is Magnific Popup object
                },
                close:function () {
                    Cookies.set('clever_prpr_pp_' + pp_version, 'shown', { expires: stt.day_next, path: '/' });
                }
                // e.t.c.
              }
            });
          };

          $('.clever_open_promopr').on('click', function (e) {
            e.preventDefault();
            showPopup();
          });

          popup.on('open_promopr', function () {
            showPopup();
          });

          if (designMode ) return;

          $('.js_lz_pppr.dn').removeClass('dn').addClass('lazyload lazypreload');
          // Detect exit
          $(document).on('mouseleave.registerexit', function(e){
            if ( e.clientY < 60 && $('.mfp-content').length == 0 && $('.popup_prpr_wrap').length > 0){
                showPopup();
            }
          });
      };

      cleverSopify.SalesPopup = function () {

        if ($('.popup_slpr_wrap').length == 0 || ($('.salse_pp_mb_false').length > 0 && $(window).width() < 768) || (Cookies.get('clever_age_verify') != 'confirmed' && $('.popup_age_wrap').length > 0)) return;

          var popup = $('.popup_slpr_wrap'),
              stt = popup.data('stt'),
              show = stt.show,
              limit = stt.limit - 1,
              pp_type = stt.pp_type,
              catLink = stt.catlink,
              arrTitle = JSON.parse($('#title_sale_pp').html()),
              arrUrl = stt.url,
              arrImage = stt.image,
              arrID = stt.id,
              arrLocation = JSON.parse($('#location_sale_pp').html()),
              arrTime = JSON.parse($('#time_sale_pp').html()),
              ClassUp = stt.ClassUp,
              ClassDown = stt.classDown[ClassUp],
              StarTimeout,StayTimeout,

              slpr_img = $('.js_slpr_img'),
              slpr_a = $('.js_slpr_a'),
              slpr_tt = $('.js_slpr_tt'),
              slpr_location = $('.js_slpr_location'),
              slpr_ago = $('.js_slpr_ago'),
              slpr_qv = $('.pp_slpr_qv'),

              index = 0,
              min = 0,
              max = arrUrl.length - 1,
              max2 = arrLocation.length - 1,
              max3 = arrTime.length - 1,
              StarTime = stt.StarTime * stt.StarTime_unit,
              StayTime = stt.StayTime * stt.StayTime_unit;

          var Updatedata = function (index) {

            // update img
            var img = arrImage[index],
                 img_url = img.replace(".jpg?v=", "_65x.jpg?v=").replace(".png?v=", "_65x.png?v=").replace(".gif?v=", "_65x.gif?v="),
                 img_url2 = img.replace(".jpg?v=", "_130x.jpg?v=").replace(".png?v=", "_130x.png?v=").replace(".gif?v=", "_130x.gif?v=");
            slpr_img.attr('src',img_url).attr('srcset',img_url+' 1x,'+img_url2+' 2x');

            // update title
            slpr_tt.text(arrTitle[index]);

            // update link
            slpr_a.attr('href',arrUrl[index]);

            // update id quick view
            slpr_qv.attr('data-id',arrID[index]);

            // update location
            slpr_location.text(arrLocation[cleverSopify.getRandomInt(min, max2)]);

            // update time
            slpr_ago.text(arrTime[cleverSopify.getRandomInt(min, max3)]);

            showSlaesPopUp();
          };

          // Load sales popup
          var loadSalesPopup = function () {
              if (pp_type == '1') {
                Updatedata(index);
                ++index;
                if (index > limit || index > max) {index = 0}

              } else {
               Updatedata(cleverSopify.getRandomInt(min, max));
              }

              StayTimeout = setTimeout(function() {
                  unloadSalesPopup();
              }, StayTime);
         };

         // unLoad sales popup
         var unloadSalesPopup = function () {
            hideSlaesPopUp();
            StarTimeout = setTimeout(function(){

               loadSalesPopup();

            }, StarTime);
         };
         var showSlaesPopUp = function () {
           popup.removeClass('hide').addClass(ClassUp).removeClass(ClassDown);
         };

         var hideSlaesPopUp = function () {
            popup.removeClass(ClassUp).addClass(ClassDown);
         };

         $(".pp_slpr_close").on("click", function(e){
             e.preventDefault();
            hideSlaesPopUp();
            clearTimeout(StayTimeout);
            clearTimeout(StarTimeout);
         });

         popup.on('open_slpr_pp', function () {
            unloadSalesPopup();
         });

         if (designMode ) return;

         // Run unloadSalesPopup
         unloadSalesPopup();

      };


})( jQueryCS );

jQueryCS(document).ready(function($) {

  cleverSopify.NewsletterPopup();
  cleverSopify.ageVerify();
  cleverSopify.cookiesLawPP();
  cleverSopify.PromoPrPopup();
  cleverSopify.stickyFooter();
  cleverSopify.swatchesOnBGGrid();
  cleverSopify.cartPosDropdown();
  cleverSopify.ideaIntent();
  cleverSopify.currencyForm();
  cleverSopify.popupMFP();
  cleverSopify.headerCategoriesMenu();
  cleverSopify.initQuickView();
  cleverSopify.quickShop();
  cleverSopify.InitPopupVideo();
  cleverSopify.InitPopupHTML();
  cleverSopify.Init360Video();
  cleverSopify.add_loading();
  cleverSopify.footerCollapse();
  cleverSopify.mobileNav();
  cleverSopify.backToTop();
  cleverSopify.InitHTMLVideo();

  $('.js_lz_slpr.dn').removeClass('dn').addClass('lazyload').one('lazyincluded', function(e) {
        cleverSopify.SalesPopup();
  });

  if ( designMode) {
    cleverSopify.SalesPopup();
  }

  if (JSCS.data('cusjs') == 'none') return;
  $script(JSCS.data('cusjs'));
});