// DOCUMENT https://doc.cleversopify.com/como/features/custom-review-app#custom-review-apps
(function( $ ) {
   "use strict";

   cleverSopify.reviewOther = function () {
   	$('body').on('reviewOther', function () {
      // any code css
      // 1. Areviews - Reviews Importer
    });
   };


})( jQueryCS );

jQueryCS(document).ready(function($) {
  cleverSopify.reviewOther();
});
